Crossroads attachment starter meshes
Original models by Quaternius, Ultimate LowPoly Gun Pack, under CC0 1.0.
Source: https://opengameart.org/content/low-poly-guns-pack
License: https://creativecommons.org/publicdomain/zero/1.0/
Models are unmodified. FBX, OBJ with MTL, and the original Blender files are provided.

Meshes: bipod, flashlight, three scope options, five suppressor options and one stock.
The stock and scopes can serve as prototypes while final variants are sourced.
Use this as a stylized prototype set. Weapon-specific sockets, scale and pivots
still need to be checked in Unreal.

Additional asset sources
- IR optic: REAP-IR on Fab
  https://www.fab.com/listings/09581f18-3fdc-4a69-bc45-22cb322bc4f8
- Variable zoom: LPVO ORION by max.zolot (CC BY 4.0)
  https://sketchfab.com/3d-models/lpvo-orion-scope-13ce4a2d4cc0463eb660f82d771f219e
- Visible laser and IR housing: URG-I SOCOM or AN/PEQ 2 by D_U (CC BY 4.0)
  https://sketchfab.com/3d-models/low-poly-urg-i-socom-3533ef82f07742e1a261d5ccced627a7
  https://sketchfab.com/3d-models/low-poly-anpeq-2-820ee672677a4f8daab617f1723820a2
- Muzzle brake: Muzzle Device Set by D_U (CC BY 4.0)
  https://sketchfab.com/3d-models/low-poly-muzzle-device-set-07f62ec5ca604446848d1a0238b11f1d
- Extended magazines: Weapon Attachment Pack on Fab, 18 shapes; confirm fit per gun
  https://www.fab.com/listings/bbcd7a12-9303-495e-b873-246c9a0189b3
- Sling and quick magazine: M16A1 by Matthew Krause, includes cloth sling and jungle mag
  https://matthewkrause.artstation.com/store/8gy5d/m16a1
- Faster bolt: existing Crossroads sniper rig has Sniper_bolt and Sniper_boltback joints.
  A unique cosmetic bolt would need a separate mesh matched to the existing rifle.
